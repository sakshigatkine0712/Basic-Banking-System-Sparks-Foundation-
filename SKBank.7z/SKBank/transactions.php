<!--********************* Code By Sakshi Gatkine *****************-->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transfer History</title>
    <!--******************** fonts-awsome link *****************-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="css/table.css">
    <link rel="stylesheet" type="text/css" href="css/navbar.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body style="background-color :DarkSlateGray;">


<nav>
    <a href="index.html"><img src="images/logo.png"></a>  
     <div class="nav-links" id="navlinks">
         <i class="fas fa-times" onclick="hideMenu()"></i>
    <ul>
         <li><a aria-current="page" href="index.php">HOME</a></li>
        <li><a aria-current="page" href="customers.php">OUR CUSTOMERS</a></li>
        <li><a aria-current="page" href="transactions.php">TRANSFER HISTORY </a></li>
        <li><a aria-current="page" href="https://www.xe.com/currencyconverter/convert/?Amount=20&From=INR&To=EUR">CURRENCY CONVERTOR</a></li>
        <li><a href="contact.php">CONTACT US</a></li>
    </ul>       
    </div>
        <i class="fas fa-bars" onclick="showMenu()"></i>
    </nav>
   
    


	<div class="container">
        <h2 class="text-center pt-4" style="color : white;">Transfer History</h2>
        
       <br>
       <div class="table-responsive-sm">
    <table class="table table-hover table-striped table-condensed table-bordered">
        <thead style="color : white;">
            <tr>
                <th class="text-center">S.No.</th>
                <th class="text-center">Sender</th>
                <th class="text-center">Receiver</th>
                <th class="text-center">Amount</th>
                <th class="text-center">Date & Time</th>
            </tr>
        </thead>
        <tbody>
        <?php

            include 'config.php';

            $sql ="select * from transaction";

            $query =mysqli_query($conn, $sql);

            while($rows = mysqli_fetch_assoc($query))
            {
        ?>

            <tr style="color : white;">
            <td class="py-2"><?php echo $rows['sno']; ?></td>
            <td class="py-2"><?php echo $rows['sender']; ?></td>
            <td class="py-2"><?php echo $rows['receiver']; ?></td>
            <td class="py-2"><?php echo $rows['balance']; ?> </td>
            <td class="py-2"><?php echo $rows['datetime']; ?> </td>   
       <?php
            }
            ?>
        </tbody>
    </table>
        </div>
    </div>
    
     <!-- footer section starts  -->

<section class="footer">

    <div class="share">
        <a href="https://www.facebook.com/campaign/landing.php?campaign_id=14884913640&extra_1=s%7Cc%7C550525804791%7Ce%7Cfacebook%7C&placement=&creative=550525804791&keyword=facebook&partner_id=googlesem&extra_2=campaignid%3D14884913640%26adgroupid%3D128696220912%26matchtype%3De%26network%3Dg%26source%3Dnotmobile%26search_or_content%3Ds%26device%3Dc%26devicemodel%3D%26adposition%3D%26target%3D%26targetid%3Dkwd-1001394929%26loc_physical_ms%3D1007786%26loc_interest_ms%3D%26feeditemid%3D%26param1%3D%26param2%3D&gclid=EAIaIQobChMI0rjOke6u9QIVyn0rCh3HEw7EEAAYASAAEgKZZfD_BwE" class="fab fa-facebook"></a>
        <a href="https://twitter.com/i/flow/login?input_flow_data=%7B%22requested_variant%22%3A%22eyJsYW5nIjoiZW4ifQ%3D%3D%22%7D" class="fab fa-twitter"></a>
        <a href="https://www.instagram.com/" class="fab fa-instagram"></a>
        <a href="https://www.linkedin.com/uas/login?session_redirect=https%3A%2F%2Fwww.linkedin.com%2Ffeed%2F%3Ftrk%3DIN-SEM_google-adwords_Jordan-brand-sign-up" class="fab fa-linkedin"></a>
        <a href="https://in.pinterest.com/login/" class="fab fa-pinterest"></a>
    </div>
<div class="para"><p> This Website is Created By Sakshi Gatkine. It is a part of Sparks Foundation Internship. This website is created using html, css, bootstrap framework as frontend , php as backend and PhpMyadmin sql as Database.</p></div>
   
    <div class="credit"><h6>© Copyright 2022 by <span> Sakshi Gatkine </span> | all rights reserved | Spark Foundation.</h6></div>

     
    
</section>

<!-- footer section ends -->
    
    
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>  
    
    <script>
    var navlinks=document.getElementById("navlinks");
        function showMenu(){
            navlinks.style.right="0";// menu will be visible 
        }
        function hideMenu(){
            navlinks.style.right="-200px"; // menu will be hide
        }
        
        
    </script>
    
    
</body>
</html>
