
<!--********************* Code By Sakshi Gatkine *****************-->
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="with=device-width, initial-scale=1.0">
    <title>SK Bank - Honours yours trust</title> 
    <!--************ custom css file link ********-->
    <link rel="stylesheet" href="css/style.css">
    <!--******************** fonts-awsome link *****************-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!--******************** bootstrap link **********************-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/style.css">
</head>
    
<body>
  <section class="header">
    <nav>
    <a href="index.html"><img src="images/logo.png"></a>  
     <div class="nav-links" id="navlinks">
         <i class="fas fa-times" onclick="hideMenu()"></i>
    <ul>
         <li><a aria-current="page" href="index.php">HOME</a></li>
        <li><a aria-current="page" href="customers.php">OUR CUSTOMERS</a></li>
        <li><a aria-current="page" href="transactions.php">TRANSFER HISTORY </a></li>
        <li><a aria-current="page" href="https://www.xe.com/currencyconverter/convert/?Amount=20&From=INR&To=EUR">CURRENCY CONVERTOR</a></li>
        <li><a href="contact.php">CONTACT US</a></li>
    </ul>       
    </div>
        <i class="fas fa-bars" onclick="showMenu()"></i>
    </nav>
   
      <!--****************center text on image **************-->
      <div class="text-box">
      <h1>SK Bank - Honours yours trust</h1>
      <p>A bank is a financial institution which performs the deposit and lending function.<br> A bank allows a person with excess money (Saver) to deposit his money in the bank and earns an interest rate</p>
        <a href="contact.php" class="hero-btn">Visit Us To Know More</a>
      </div>   
</section>  
    

    <!--********************* about Section *******************-->
  <section class="serviceoffers" id="servicediv">
    <div class="container headings1 text-center">
    <h1 class="text-center font-weight-bold">WHAT DO WE OFFER</h1> 
       <h6> <p class="text-center">Some of the Features that SK Bank Offers to Their Customers.</p></h6><br>
    </div>    
        
        <div class="container ">
        <div class="row">
        <div class="col-lg-6 col-md-12 col-10 offset-1 offset-lg-0 image1 ">
            <img src="images/f1.jpg" class="img-fluid"> <br>
            <img src="images/f2.jpg" class="img-fluid"> 
             </div>
            
            <div class="col-lg-6 col-md-12 col-12 servicediv">
             <h4>SK Bank - Honours yours trust</h4><br>
     <h6> 
          <p>@ Great customer service</p>
                <p>Solid customer service is something you should demand from any business -- but especially your bank. Aim for a bank whose customer service team is easily accessible (meaning, no 30-minute waits to speak to a live person).
          <p>@ Low account fees</p>
         <p>Why pay money to keep your money somewhere? Aim to find a bank account whose fees are minimal or nonexistent. There are plenty of checking accounts out there, for example, that don't impose a minimum balance. And you shouldn't settle for a bank that will charge you for things like online bill paying or replacement debit cards.</p>
          <p>@ Security and fraud protection</p>
         <p>If a criminal gains access to your bank account, the results could be catastrophic. Aim to find a bank with strong security measures in place both at its physical locations as well as online. As a basic measure, your bank should require a complex password for you to sign in and access your account information.</p>
         <p>@ Mobile and online access</p>
                <p>Let's face it -- most of us are tied to our mobile phones these days. To that end, be sure to find a bank that lets you access your account on the go. It'll make managing your bills and money more convenient.</p>
            <p>@ Solid brand reputation</p>
            <p>You may have plenty of luck going with a local community bank that doesn't have dozens upon dozens of branches. But there is something to be said about choosing a bank whose name is easily recognizable and whose reputation is solid.</p>    
                </h6>           
        </div>
    </div>
</div>
    </section>
    
    
    <!-- footer section starts  -->

<section class="footer">

    <div class="share">
        <a href="https://www.facebook.com/campaign/landing.php?campaign_id=14884913640&extra_1=s%7Cc%7C550525804791%7Ce%7Cfacebook%7C&placement=&creative=550525804791&keyword=facebook&partner_id=googlesem&extra_2=campaignid%3D14884913640%26adgroupid%3D128696220912%26matchtype%3De%26network%3Dg%26source%3Dnotmobile%26search_or_content%3Ds%26device%3Dc%26devicemodel%3D%26adposition%3D%26target%3D%26targetid%3Dkwd-1001394929%26loc_physical_ms%3D1007786%26loc_interest_ms%3D%26feeditemid%3D%26param1%3D%26param2%3D&gclid=EAIaIQobChMI0rjOke6u9QIVyn0rCh3HEw7EEAAYASAAEgKZZfD_BwE" class="fab fa-facebook"></a>
        <a href="https://twitter.com/i/flow/login?input_flow_data=%7B%22requested_variant%22%3A%22eyJsYW5nIjoiZW4ifQ%3D%3D%22%7D" class="fab fa-twitter"></a>
        <a href="https://www.instagram.com/" class="fab fa-instagram"></a>
        <a href="https://www.linkedin.com/uas/login?session_redirect=https%3A%2F%2Fwww.linkedin.com%2Ffeed%2F%3Ftrk%3DIN-SEM_google-adwords_Jordan-brand-sign-up" class="fab fa-linkedin"></a>
        <a href="https://in.pinterest.com/login/" class="fab fa-pinterest"></a>
    </div>
<div class="para"><p> This Website is Created By Sakshi Gatkine. It is a part of Sparks Foundation Internship. This website is created using html, css, bootstrap framework as frontend , php as backend and PhpMyadmin sql as Database.</p></div>
   
    <div class="credit"><h6>© Copyright 2022 by <span> Sakshi Gatkine </span> | all rights reserved | Spark Foundation.</h6></div>

     
    
</section>

<!-- footer section ends -->
    
    
 
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>  
    
    <script>
    var navlinks=document.getElementById("navlinks");
        function showMenu(){
            navlinks.style.right="0";// menu will be visible 
        }
        function hideMenu(){
            navlinks.style.right="-200px"; // menu will be hide
        }
        
      
        
        
        
    </script>
    
</body>    
    

</html>