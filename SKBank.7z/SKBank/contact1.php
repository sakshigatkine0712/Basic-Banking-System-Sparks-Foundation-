<!--********************* Code By Sakshi Gatkine *****************-->

<!--***************** php code for contact form *****************-->

<?php
include 'config.php'; /****** database connection file *******/

mysqli_select_db($conn,'bankdb');/********* select database bankdb from mysql (phpmyadmin)****/


/********* store form values inside the variable using post method *************/
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$message = $_POST['message'];

/************ values should be insert into mysql contact_form table********/
$sql ="INSERT INTO contact_form ( name, email, phone, message )VALUES ('$name','$email','$phone','$message')";

/********* execute by using mysqli_query() method*****************/
$query = mysqli_query($conn , $sql);


/******** after submit the form user will redirect to contact.php page****/
header('location:contact.php');

?>
        